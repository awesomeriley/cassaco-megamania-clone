/**
 * Arquivo que representa o video que ser� exibido e ser�
 * o responsavel por exibir todas telas do JOGO
 *
 * Author: Adriano Braga Alencar (adrianobragaalencar@gmail.com) 
 *
 */

#ifndef __SDL_VIDEO_H__
#define __SDL_VIDEO_H__

class {
	private:
	public:
};

#endif //__SDL_VIDEO_H__
